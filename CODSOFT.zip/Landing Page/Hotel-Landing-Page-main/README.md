# Hotel Landing Page

A simple front-end hotel landing page using HTML, CSS, and HTML.

URL: https://michaelzhou334.github.io/Hotel-Landing-Page/
